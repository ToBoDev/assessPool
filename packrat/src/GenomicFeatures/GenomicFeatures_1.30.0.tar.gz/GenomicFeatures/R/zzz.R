.test <- function() BiocGenerics:::testPackage("GenomicFeatures")

