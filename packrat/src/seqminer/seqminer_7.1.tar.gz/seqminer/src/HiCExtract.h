#ifndef _HICEXTRACT_H_
#define _HICEXTRACT_H_



#endif /* _HICEXTRACT_H_ */
