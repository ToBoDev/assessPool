library("testthat")
library("Rdpack")

test_check("Rdpack")
