### R code from vignette source 'Rsamtools-UsingCLibraries.Rnw'

###################################################
### code chunk number 1: style
###################################################
BiocStyle::latex()


