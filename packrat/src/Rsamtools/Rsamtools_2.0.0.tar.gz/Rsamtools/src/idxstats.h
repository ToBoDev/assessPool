#ifndef _IDXSTATS_H
#define _IDXSTATS_H

#include <Rinternals.h>

SEXP idxstats_bamfile(SEXP bfile);

#endif
