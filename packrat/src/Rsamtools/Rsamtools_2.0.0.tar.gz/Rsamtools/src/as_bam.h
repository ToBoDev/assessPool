#ifndef _AS_BAM_H_
#define _AS_BAM_H_

#include <Rinternals.h>

SEXP as_bam(SEXP file, SEXP destination, SEXP binary);

#endif                          /* _AS_BAM_H_ */
