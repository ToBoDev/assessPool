library(testthat)
library(biomaRt)

test_check("biomaRt")