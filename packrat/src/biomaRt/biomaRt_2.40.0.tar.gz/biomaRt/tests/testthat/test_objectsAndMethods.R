

dummy_mart <- new("Mart", 
            biomart = "example_name",
            vschema = "default", 
            host = "http://www.example.com:80/biomart/martservice")